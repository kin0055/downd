/* This file is auto generated, version 42-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#42-Ubuntu SMP Tue Oct 23 15:48:01 UTC 2018"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lgw01-amd64-054"
#define LINUX_COMPILER "gcc version 7.3.0 (Ubuntu 7.3.0-16ubuntu3)"
